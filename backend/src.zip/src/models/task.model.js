import mongoose from "mongoose";

const taskSchema = new mongoose.Schema({ 
    title: {
        type: String,
        required: true
    },
    description: {
        type: String,
    },
    status: {
        type: String,
        enum: ["pending", "in-progress", "completed"],
        default: "pending"
    },
    priority: {
        type: String,
        enum: ["low", "medium", "high"],
        default: "medium"
    },
    dueDate: Date,

    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    createdAt: {
        type: Date,
        default: Date.now
    },

    externalEventId: {
        type: String,
        index: true
    }

});

taskSchema.index({ userId: 1, externalEventId: 1 }, { unique: true });
export const Task = mongoose.model("Task", taskSchema);